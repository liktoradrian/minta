import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

export function RecipeEdit() {
    const navigate = useNavigate();
    const param = useParams();
    const id = param.receptId;
    const [recipe, setRecipe] = useState({});
    const [isPending, setPending] = useState(false);

    useEffect(() => {
        setPending(true);
          (async () => {
            try {
                await axios.post(`https://localhost:9090/api/recipes/${id}`, {
                    name: e.target.elements.name.value,
                    price: e.target.elements.price.value,
                    quantity: e.target.elements.quantity.value,
                    imageURL: e.target.elements.imageURL.value,
                }, {withCredentials: true});
                navigate("/uj-recept");
              } catch (err) {
                console.log(err);
              }
            })();
        })

      return (
        <div className="p-5  m-auto text-center content bg-lavender">
          {isPending || !recipe.id ? (
            <div className="spinner-border"></div>
          ) : (
            <div className="card p-3">
              <div className="card-body">
                <h4>{recipe.brand}</h4>
                <h5 className="card-title">{recipe.name}</h5>
                <div className="lead">{recipe.price} ft</div>
                <p>Készleten: {recipe.quantity} db</p>
                <img
                  className="img-fluid rounded"
                  style={{ maxHeight: "500px" }}
                  src={recipe.imageURL ? recipe.imageURL : "https://via.placeholder.com/400x800"}
                />
              </div>
            </div>
          )}
        </div>
      );
  }