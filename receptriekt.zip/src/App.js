import { BrowserRouter, NavLink, Route, Routes } from 'react-router-dom';
import './App.css';
import images from './logo.png';


function App() {
  return (
    <BrowserRouter>
      <div className='nagyDiv'>
        <nav className="navbar navbar-expand-sm navbar-dark bg-primary">

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <img className='logo' src={images} alt='logo' title='logo'></img>
          <li className="nav-item">
            <NavLink to={`/`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")} end>
              <span className="nav-link">Recept</span>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink to={`/uj-recept`} className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}>
              <span className="nav-link">Új Recept</span>
            </NavLink>
          </li>
        </ul>
      </div>
    </nav>
    </div>
    </BrowserRouter>
  );
}

export default App;
