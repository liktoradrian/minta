﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace csudh
{
    public class csudh
    {
        static void Main(string[] args)
        {
            List<ipCim> cimek = new List<ipCim>();
            StreamReader reader = new StreamReader("csudh.txt");
            reader.ReadLine();
            while (!reader.EndOfStream)
            {
                string[] mezok = reader.ReadLine().Split(';');
                ipCim egyIpCim = new ipCim(mezok[0], mezok[1]);
                cimek.Add(egyIpCim);
            }
            reader.Close();
            Console.WriteLine($"3. feladat: Domain-Ip párosok száma: {cimek.Count}db");
            foreach (var item in cimek)
            {
                Console.WriteLine($"Domain-Ip párosok adatai: {item.DomainName + " " + item.IpAddress}");
            }
            Console.ReadKey();
        }
    }
}