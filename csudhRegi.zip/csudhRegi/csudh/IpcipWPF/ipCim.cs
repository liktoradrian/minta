﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IpcipWPF
{
    internal class ipCim
    {
        string domainName;
        string ipAddress;

        public string DomainName
        {
            get { return domainName; }
            private set { domainName = value; }
        }

        public string IpAddress
        {
            get { return ipAddress; }
            private set { ipAddress = value; }
        }

        public ipCim(string domainName, string ipAddress)
        {
            DomainName = domainName;
            IpAddress = ipAddress;
        }

        public override string ToString()
        {
            return $"{domainName} {ipAddress}";
        }
    }
}